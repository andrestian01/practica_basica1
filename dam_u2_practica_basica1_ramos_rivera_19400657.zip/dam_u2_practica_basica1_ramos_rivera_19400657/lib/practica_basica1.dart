import 'package:flutter/material.dart';

class Practica1_basica extends StatefulWidget {
  Practica1_basica({Key? key}) : super(key: key);

  @override
  _Practica1_basica createState() => _Practica1_basica();
}

class _Practica1_basica extends State<Practica1_basica> {
  bool _isChecked = false;
  String _textFieldValue = '';

  void _showSnackbar() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Has presionado el botón! y el texto escrito es: ' +  _textFieldValue),
        duration: Duration(seconds: 2),
      ),
    );
  }
  void _clear() {
    setState(() {
      _isChecked = false;
      _textFieldValue = '';
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mi aplicación Flutter'),
        actions: [
          IconButton(
              icon: Icon(Icons.clear),
              onPressed: _clear
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              onChanged: (value) {
                setState(() {
                  _textFieldValue = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Escribe algo...',
              ),
            ),
            SizedBox(height: 20),
            Text(
              'El valor del campo de texto es: $_textFieldValue',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _showSnackbar,
              child: Text('Presionar'),
            ),
            SizedBox(height: 20),
            CheckboxListTile(
              title: Text('Esto es un CheckBox'),
              value: _isChecked,
              onChanged: (value) {
                setState(() {
                  _isChecked = value!;
                  _textFieldValue = _textFieldValue + " El check box esta funcionando";
                });

              },
            ),
          ],
        ),
      ),
    );
  }
}
