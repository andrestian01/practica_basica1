import 'package:flutter/material.dart';

import 'practica_basica1.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'U2. Práctica 1. Aplicación básica 19400657',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Practica1_basica(),
    );
  }
}

