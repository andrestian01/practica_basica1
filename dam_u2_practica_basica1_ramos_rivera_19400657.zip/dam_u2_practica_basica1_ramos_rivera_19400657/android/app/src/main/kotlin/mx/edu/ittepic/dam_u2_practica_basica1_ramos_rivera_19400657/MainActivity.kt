package mx.edu.ittepic.dam_u2_practica_basica1_ramos_rivera_19400657

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
